
import json
import gurobipy as gp
from gurobipy import GRB

# Read problem data from file
with open("data.json", "r") as file:
    data = json.load(file)

# Extract data
demand = data["demand"]
max_regular_amount = data["max_regular_amount"]
cost_regular = data["cost_regular"]
cost_overtime = data["cost_overtime"]
store_cost = data["store_cost"]
N = len(demand)

# Create model
model = gp.Model("ProductionSchedule")

# Create decision variables
x = model.addVars(N, name="x")  # Number of units produced in each month
y = model.addVars(N-1, name="y")  # Number of units carried over to the next month
is_demand_met = model.addVars(N, vtype=GRB.BINARY, name="is_demand_met")  # Binary variable to represent whether demand is met

# Set objective function
max_over_regular = model.addVars(N, name="max_over_regular")  # Variable to represent max(x[n] - max_regular_amount, 0)
model.addConstrs(max_over_regular[n] >= x[n] - max_regular_amount for n in range(N))  # Constraint for max_over_regular
production_cost = sum(cost_regular * x[n] + cost_overtime * max_over_regular[n] for n in range(N))
storage_cost = sum(store_cost * y[n] for n in range(N-1))
total_cost = production_cost + storage_cost
model.setObjective(total_cost, GRB.MINIMIZE)

# Add demand constraint
model.addConstr(x[0] == demand[0])
model.addConstr(x[0] >= demand[0] * is_demand_met[0])
model.addConstrs(x[n] + y[n-1] >= demand[n] * is_demand_met[n] for n in range(1, N))

# Add non-negativity constraint
non_negativity_constraint_x = model.addConstrs(x[n] >= 0 for n in range(N))
non_negativity_constraint_y = model.addConstrs(y[n-1] >= 0 for n in range(1, N))

# Optimize the model
model.optimize()

# Extract the solution
quantity = [x[n].x for n in range(N)]

# Save the output to file
output = {"quantity": quantity}
with open("output.json", "w") as file:
    json.dump(output, file, indent=4)
