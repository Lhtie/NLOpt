
def prob_15(senior_citizens, young_adults):
    """
    Args:
        senior_citizens: an integer representing the number of senior citizens employed by the store
        young_adults: an integer representing the number of young adults employed by the store
    Returns:
        obj: an integer representing the minimized wage bill
    """
    obj = 1e9
    # To be implemented
    return obj
