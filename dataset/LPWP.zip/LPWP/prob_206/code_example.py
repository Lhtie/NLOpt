
def prob_206(plush_toys, dolls):
    """
    Args:
        plush_toys: an integer representing the number of plush toys
        dolls: an integer representing the number of dolls

    Returns:
        obj: an integer representing the maximum profit
    """
    obj = 1e9
    # To be implemented
    return obj
