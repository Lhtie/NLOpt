
def prob_161(new_one, old_one, new_one_, old_one_):
    """
    Args:
        new_one: an integer, number of gifts delivered per trip by the new company
        old_one: an integer, number of gifts delivered per trip by the old company
        new_one_: an integer, liters of diesel used per trip by the new company
        old_one_: an integer, liters of diesel used per trip by the old company

    Returns:
        total_amount_of_diesel: an integer, total amount of diesel used
    """
    total_amount_of_diesel = 1e9
    # To be implemented
    return total_amount_of_diesel
