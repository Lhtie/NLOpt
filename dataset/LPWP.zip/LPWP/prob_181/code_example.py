
def prob_181(submarine, boat):
    """
    Args:
        submarine: an integer, number of submarine trips
        boat: an integer, number of boat trips
    Returns:
        obj: an integer, minimum amount of gas used
    """
    obj = 1e9
    # To be implemented
    return obj
