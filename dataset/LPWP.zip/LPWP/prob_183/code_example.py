
def prob_183(hot_air_balloon, gondola_lift):
    """
    Args:
        hot_air_balloon: an integer, represents the maximum number of hot air balloons rides
        gondola_lift: an integer, represents the maximum number of gondola lift rides
    Returns:
        obj: an integer, the minimized total pollution produced
    """
    obj = 1e9
    # To be implemented
    return obj
