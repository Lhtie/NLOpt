
def prob_158(small_buses, large_buses):
    """

    Args:
        small_buses: an integer, number of small buses to hire
        large_buses: an integer, number of large buses to hire

    Returns:
        objective_value: an integer, the total number of buses
    """
    obj = 1e9
    # To be implemented
    return obj
