
def prob_209(regular_brand, premium_brand):
    """
    Args:
        regular_brand: an integer representing the number of bags of regular brand
        premium_brand: an integer representing the number of bags of premium brand
    Returns:
        obj: an integer representing the minimum cost
    """
    obj = 1e9
    # To be implemented
    return obj
