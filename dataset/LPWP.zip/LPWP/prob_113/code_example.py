
def prob_113(children_vaccines, adult_vaccines):
    """
    Args:
        children_vaccines: an integer representing the number of children's vaccines
        adult_vaccines: an integer representing the number of adult vaccines

    Returns:
        obj: an integer representing the objective value (amount of fever suppressant)
    """
    obj = 1e9
    # To be implemented
    return obj
