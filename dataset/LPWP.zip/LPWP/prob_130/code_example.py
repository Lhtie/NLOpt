
def prob_130(pain_killer_1, pain_killer_2):
    """
    Args:
        pain_killer_1: an integer, number of doses of pain killer 1
        pain_killer_2: an integer, number of doses of pain killer 2

    Returns:
        obj: an integer, maximum amount of medicine delivered to the back
    """
    obj = 1e9
    # To be implemented
    return obj
