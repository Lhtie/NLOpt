
def prob_190(small_crates, large_crates):
    """
    Args:
        small_crates: an integer (number of small crates),
        large_crates: an integer (number of large crates)

    Returns:
        obj: an integer (total number of grapes)
    """
    obj = 1e9
    # To be implemented
    return obj
