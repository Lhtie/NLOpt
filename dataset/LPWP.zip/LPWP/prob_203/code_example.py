
def prob_203(black_milk_tea, matcha_milk_tea):
    """
    Args:
        black_milk_tea: an integer, quantity of black milk tea to be made
        matcha_milk_tea: an integer, quantity of matcha milk tea to be made
    Returns:
        obj: a float, the maximum profit
    """
    obj = 1e9
    # To be implemented
    return obj
