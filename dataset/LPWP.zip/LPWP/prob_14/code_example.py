
def prob_14(long, short_cables, constraint1, constraint2, constraint3):
    """
    Args:
        long: an integer, the number of long cables
        short_cables: an integer, the number of short cables
        constraint1: an integer, the value of the first constraint
        constraint2: an integer, the value of the second constraint
        constraint3: an integer, the value of the third constraint

    Returns:
        obj: an integer, the objective value
    """
    obj = 1e9
    # To be implemented
    return obj
