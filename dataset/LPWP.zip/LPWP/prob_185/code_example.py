
def prob_185(labradors, golden_retrievers):
    """
    Args:
        labradors: an integer, the number of labradors used
        golden_retrievers: an integer, the number of golden retrievers used

    Returns:
        obj: an integer, the maximum number of newspapers that can be delivered
    """
    obj = 1e9
    # To be implemented
    return obj
