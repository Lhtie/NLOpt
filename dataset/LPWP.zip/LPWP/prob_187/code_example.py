
def prob_187(ferry, light_rail, constraint1, constraint2, constraint3):
    """
    Args:
        ferry: an integer, the number of ferry trips
        light_rail: an integer, the number of light rail trips
        constraint1: an integer, the first constraint parameter
        constraint2: an integer, the second constraint parameter
        constraint3: an integer, the third constraint parameter
    Returns:
        obj: an integer, the objective value
    """
    obj = 1e9
    # To be implemented
    return obj
