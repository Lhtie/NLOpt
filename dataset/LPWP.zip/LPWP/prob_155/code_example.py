
def prob_155(otters, dolphins):
    """
    Solve the problem to maximize the total number of tricks that can be performed.

    Args:
        otters: number of otters (integer)
        dolphins: number of dolphins (integer)

    Returns:
        obj: total number of tricks (integer)
    """
    obj = 1e9
    # To be implemented
    return obj
