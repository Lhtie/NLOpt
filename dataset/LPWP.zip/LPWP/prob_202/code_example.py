
def prob_202(desks, drawers, assembly_constraint, sanding_constraint):
    """
    Args:
        desks: an integer, representing the number of desks
        drawers: an integer, representing the number of drawers
        assembly_constraint: an integer, representing the available minutes for assembly
        sanding_constraint: an integer, representing the available minutes for sanding
    Returns:
        profit: an integer, representing the maximum profit
    """
    obj = 1e9
    # To be implemented
    return obj
