
def prob_160(small_bouquets, large_bouquets):
    """
    Args:
        small_bouquets: an integer, number of small bouquets
        large_bouquets: an integer, number of large bouquets
    Returns:
        obj: an integer, number of flowers
    """
    obj = 1e9
    # To be implemented
    return obj
