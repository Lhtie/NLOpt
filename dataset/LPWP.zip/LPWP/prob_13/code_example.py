
def prob_13(radio_ads, social_media_ads):
    """
    Args:
        radio_ads: an integer representing the number of radio ads
        social_media_ads: an integer representing the number of social media ads
    Returns:
        obj: an integer representing the maximum exposure
    """
    obj = 1e9
    # To be implemented
    return obj
