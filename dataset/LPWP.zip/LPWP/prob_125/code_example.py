
def prob_125(anxiety_medication, anti_depressants):
    """
    Args:
        anxiety_medication: an integer (number of units of anxiety medication)
        anti_depressants: an integer (number of units of anti-depressants)
    Returns:
        total_time: an integer (total time it takes for the medication to be effective)
    """
    total_time = 1e9
    # To be implemented
    return total_time
