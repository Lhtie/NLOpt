
def prob_159(trucks, vans):
    """
    Args:
        trucks: an integer, number of trucks
        vans: an integer, number of vans
    Returns:
        obj: an integer, number of trips
    """
    obj = 1e9
    # To be implemented
    return obj
