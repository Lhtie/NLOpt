
def prob_168(scooter, rickshaw):
    """
    Args:
        scooter: an integer, number of scooters used
        rickshaw: an integer, number of rickshaws used

    Returns:
        obj: an integer, total number of scooters used
    """
    obj = 1e9
    # To be implemented
    return obj
