def prob_20(banana_haters_package, combo_package):
    """
    Args:
        banana_haters_package: an integer representing the quantity of banana-haters packages
        combo_package: an integer representing the quantity of combo packages
    Returns:
        obj: an integer representing the maximum net profit
    """
    obj = 1e9
    # To be implemented
    return obj

