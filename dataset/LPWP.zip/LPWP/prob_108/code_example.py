
def prob_108(regular_batch, premium_batch):
    """
    Args:
        regular_batch: an integer, number of regular batches
        premium_batch: an integer, number of premium batches
    Returns:
        obj: an integer, number of people treated
    """
    obj = 1e9
    # To be implemented
    return obj
