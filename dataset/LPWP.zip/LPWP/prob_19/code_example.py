
def prob_19(thin_jar, stubby_jar):
    """
    Args:
        thin_jar: an integer, the number of thin jars
        stubby_jar: an integer, the number of stubby jars
    Returns:
        obj: an integer, the maximum profit
    """
    obj = 1e9
    # To be implemented
    return obj
