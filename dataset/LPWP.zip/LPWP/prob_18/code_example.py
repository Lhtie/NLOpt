
def prob_18(Feed_A, Feed_B):
    """
    Args:
        Feed_A: an integer, representing the amount of Feed A
        Feed_B: an integer, representing the amount of Feed B
    Returns:
        obj: an integer, representing the minimum cost of the mixture
    """
    obj = 1e9
    # To be implemented
    return obj
