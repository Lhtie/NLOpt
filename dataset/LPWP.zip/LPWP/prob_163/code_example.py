
def prob_163(helicopters, trucks):
    """
    Args:
        helicopters: an integer, the number of helicopters
        trucks: an integer, the number of trucks
    Returns:
        obj: an integer, the amount of pollution
    """
    obj = 1e9
    # To be implemented
    return obj
