
def prob_178(bike, car):
    """
    Args:
        bike: an integer, represents the number of bikes
        car: an integer, represents the number of cars
    Returns:
        obj: an integer, the objective value
    """
    obj = 1e9
    # To be implemented
    return obj
