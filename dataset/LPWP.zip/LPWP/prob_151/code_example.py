
def prob_151(ships, planes):
    """
    Args:
        ships: an integer, representing the number of ship trips
        planes: an integer, representing the number of plane trips
    Returns:
        obj: an integer, representing the total amount of fuel consumed
    """
    obj = 1e9
    # To be implemented
    return obj
