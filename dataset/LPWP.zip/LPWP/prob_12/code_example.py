
def prob_12(regular, special, constraint1, constraint2):
    """
    Args:
        regular: an integer, the number of regular sandwiches
        special: an integer, the number of special sandwiches
        constraint1: an integer, the first constraint value
        constraint2: an integer, the second constraint value
    Returns:
        obj: an integer, the objective value (profit)
    """
    obj = 1e9
    # To be implemented
    return obj
