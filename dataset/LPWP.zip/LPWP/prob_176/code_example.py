
def prob_176(small, large):
    """
    Args:
        small: an integer, number of small jars
        large: an integer, number of large jars
    Returns:
        obj: an integer, the objective value
    """
    obj = 1e9
    # To be implemented
    return obj
