
def prob_123(painkillers, sleeping_pills):
    """
    Args:
        painkillers: an integer, representing the number of painkiller pills
        sleeping_pills: an integer, representing the number of sleeping pills
    Returns:
        amount_of_digestive_medicine: an integer, representing the total amount of digestive medicine needed  
    """
    obj = 1e9
    # To be implemented
    return obj
