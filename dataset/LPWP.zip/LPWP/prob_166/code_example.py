
def prob_166(large, small, large_planes, small_planes):
    """
    Args:
        large: an integer, the number of large planes
        small: an integer, the number of small planes
        large_planes: an integer, the number of large planes
        small_planes: an integer, the number of small planes
    Returns:
        obj: an integer, the objective value
    """
    obj = 1e9
    # To be implemented
    return obj
