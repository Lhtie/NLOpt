
def prob_198(vans, cars):
    """
    Solve the voter transportation problem.

    Args:
        vans: an integer, number of vans
        cars: an integer, number of cars

    Returns:
        obj: an integer, total number of cars used
    """
    obj = 1e9
    # To be implemented
    return obj
