
def prob_196(large_ships, small_ships):
    """
    Args:
        large_ships: an integer, number of large ships
        small_ships: an integer, number of small ships
    Returns:
        objective_value: an integer, the objective value
    """
    objective_value = 1e9
    # To be implemented
    return objective_value
