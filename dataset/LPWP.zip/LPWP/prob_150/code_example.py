
def prob_150(small_bottles, large_bottles):
    """
    Args:
        small_bottles: an integer, the number of small bottles
        large_bottles: an integer, the number of large bottles
        
    Returns:
        amount_of_honey: an integer, the maximum amount of honey that can be transported
    """
    amount_of_honey = 1e9
    # To be implemented
    return amount_of_honey
