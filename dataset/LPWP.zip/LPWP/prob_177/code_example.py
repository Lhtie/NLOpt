
def prob_177(tractor, car, twice):
    """
    Args:
        tractor: an integer, representing the number of tractors used
        car: an integer, representing the number of cars used
        twice: an integer, representing the minimum number of cars compared to tractors
    Returns:
        obj: an integer, representing the minimized total number of tractors and cars needed
    """
    obj = 1e9
    # To be implemented
    return obj
