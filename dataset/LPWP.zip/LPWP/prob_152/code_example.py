
def prob_152(boat, canoe):
    """
    Args:
        boat: an integer, number of trips by boat
        canoe: an integer, number of trips by canoe
    Returns:
        obj: an integer, total amount of time needed to transport the ducks
    """
    obj = 1e9
    # To be implemented
    return obj
