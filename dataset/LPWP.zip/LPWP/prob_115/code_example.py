
def prob_115(fertilizer, seeds):
    """
    Args:
        fertilizer: an integer, the number of units of fertilizer
        seeds: an integer, the number of units of seeds
    Returns:
        obj: an integer, the total time it takes for the lawn to be ready
    """
    obj = 1e9
    # To be implemented
    return obj
