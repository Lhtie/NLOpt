
def prob_154(small_teams, large_teams):
    """
    Args:
        small_teams: an integer
        large_teams: an integer
    Returns:
        obj: an integer, the amount of lawn that can be mowed
    """
    obj = 1e9
    # To be implemented
    return obj
