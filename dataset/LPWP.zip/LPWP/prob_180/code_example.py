
def prob_180(small, large):
    """
    Args:
        small: an integer, representing the number of small kegs
        large: an integer, representing the number of large kegs
    Returns:
        obj: an integer, representing the maximum amount of glacial water that can be transported
    """
    obj = 1e9
    # To be implemented
    return obj
