
def prob_126(machine_1, machine_2, constraint1, constraint2, constraint3):
    """
    Args:
        machine_1: an integer (number of hours for machine 1)
        machine_2: an integer (number of hours for machine 2)
        constraint1: an integer (value of constraint 1)
        constraint2: an integer (value of constraint 2)
        constraint3: an integer (value of constraint 3)
    Returns:
        obj: an integer (objective value - total time)
    """
    obj = 1e9
    # To be implemented
    return obj
