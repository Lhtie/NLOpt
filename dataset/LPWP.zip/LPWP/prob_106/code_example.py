
def prob_106(factory_1, factory_2):
    """
    Args:
        factory_1: an integer, number of hours factory 1 should be run
        factory_2: an integer, number of hours factory 2 should be run

    Returns:
        obj: an integer, the minimum total time needed
    """
    obj = 1e9
    # To be implemented
    return obj
