
def prob_172(bus, car):
    """
    Args:
        bus: an integer
        car: an integer
    Returns:
        obj: an integer
    """
    obj = 1e9
    # To be implemented
    return obj
