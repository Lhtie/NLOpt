
def prob_147(beam_bridges, truss_bridges):
    """
    Args:
        beam_bridges: an integer, representing the number of beam bridges
        truss_bridges: an integer, representing the number of truss bridges
        
    Returns:
        obj: an integer, representing the maximum total mass that can be supported
    """
    obj = 1e9
    # To be implemented
    return obj
