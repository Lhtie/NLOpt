
def prob_10(A, B, constraint1, constraint2, constraint3):
    """
    Args:
        A: an integer, kg of fertilizer A
        B: an integer, kg of fertilizer B
        constraint1: an integer, constraint 1 value
        constraint2: an integer, constraint 2 value
        constraint3: an integer, constraint 3 value
    Returns:
        obj: an integer, amount of vitamin D
    """
    obj = 1e9
    # To be implemented
    return obj
