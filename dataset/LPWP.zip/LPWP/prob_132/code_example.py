
def prob_132(table_1, table_2):
    """
    Args:
        table_1: an integer,
        table_2: an integer,
    Returns:
        obj: an integer,
    """
    obj = 1e9
    # To be implemented
    return obj
