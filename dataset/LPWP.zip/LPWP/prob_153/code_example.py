
def prob_153(old_vans, new_vans):
    """
    Args:
        old_vans: an integer, the number of old vans
        new_vans: an integer, the number of new vans
    Returns:
        obj: an integer, the total amount of pollution produced
    """
    obj = 1e9
    # To be implemented
    return obj
