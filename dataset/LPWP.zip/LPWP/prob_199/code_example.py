
def prob_199(hamburgers, chicken_wraps):
    """
    Args:
        hamburgers: an integer, representing the number of hamburgers
        chicken_wraps: an integer, representing the number of chicken wraps
    Returns:
        obj: an integer, representing the minimum cost
    """
    obj = 1e9
    # To be implemented
    return obj
