
def prob_204(milk, vegetables):
    """
    Args:
        milk: an integer, amount of milk
        vegetables: an integer, amount of vegetables
    Returns:
        obj: an integer, objective value (cost)
    """
    obj = 1e9
    # To be implemented
    return obj
