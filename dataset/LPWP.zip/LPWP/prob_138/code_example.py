
def prob_138(medicine_A, medicine_B):
    """
    Args:
        medicine_A: number of doses for medicine A (integer)
        medicine_B: number of doses for medicine B (integer)
    Returns:
        obj: maximum number of people that can be treated (integer)
    """
    obj = 1e9
    # To be implemented
    return obj
