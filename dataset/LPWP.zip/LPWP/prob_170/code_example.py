
def prob_170(small_suitcases, large_suitcases):
    """
    Args:
        small_suitcases: an integer, the number of small suitcases
        large_suitcases: an integer, the number of large suitcases
    Returns:
        number_of_snacks: an integer, the maximum number of snacks that can be delivered
    """
    obj = 1e9
    # To be implemented
    return obj
