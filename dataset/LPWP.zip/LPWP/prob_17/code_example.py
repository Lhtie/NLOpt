
def prob_17(chair, dresser, constraint1, constraint2):
    """

    Args:
        chair: an integer, the number of chairs produced by Elm Furniture
        dresser: an integer, the number of dressers produced by Elm Furniture
        constraint1: a float, the constraint for stain availability
        constraint2: a float, the constraint for oak wood availability
    Returns:
        obj: a float, the maximum profit
    """
    obj = 1e9
    # To be implemented
    return obj
