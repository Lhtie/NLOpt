
def prob_139(spit_tests, swabs):
    """
    Args:
        spit_tests: an integer, the number of spit tests
        swabs: an integer, the number of swabs
    Returns:
        obj: an integer, the objective value
    """
    obj = 1e9
    # To be implemented
    return obj
