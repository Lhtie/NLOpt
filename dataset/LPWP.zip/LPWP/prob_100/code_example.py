
def prob_100(Pill_1, Pill_2):
    """
    Args:
        Pill_1: an integer, the number of Pill 1 taken
        Pill_2: an integer, the number of Pill 2 taken
    Returns:
        obj: an integer, the total amount of discharge
    """
    obj = 1e9
    # To be implemented
    return obj
