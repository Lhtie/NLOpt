
def prob_116(factory_1, factory_2, base_gel):
    """
    Args:
        factory_1: an integer, units of acne cream produced by factory 1 per hour
        factory_2: an integer, units of acne cream produced by factory 2 per hour
        base_gel: an integer, units of base gel required by both factories per hour
    Returns:
        total_time: an integer, total time needed to minimize the total time
    """
    total_time = 1e9
    # To be implemented
    return total_time
