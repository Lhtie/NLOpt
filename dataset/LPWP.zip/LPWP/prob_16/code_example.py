
def prob_16(z_tube, soorchle, wassa):
    """
    Args:
        z_tube: an integer representing the number of advertisements on z-tube
        soorchle: an integer representing the number of advertisements on soorchle
        wassa: an integer representing the number of advertisements on wassa

    Returns:
        obj: an integer representing the maximized total audience
    """
    obj = 1e9
    # To be implemented
    return obj
