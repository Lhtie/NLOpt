
def prob_167(small_wagons, large_wagons, twice):
    """
    Args:
        small_wagons: an integer, number of small wagons
        large_wagons: an integer, number of large wagons
        twice: an integer, twice the number of large wagons
    Returns:
        obj: an integer, number of wagons
    """
    obj = 1e9
    # To be implemented
    return obj
